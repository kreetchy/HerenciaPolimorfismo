public abstract class Car implements Vehicle {

    private CarType type;

    private String carID;

    int maxSpeed;

    public Car(CarType type, String carID, int maxSpeed) {
        this.type = type;
        this.carID = carID;
        this.maxSpeed = maxSpeed;
    }
    

    public CarType getType() {
        return type;
    }

    public String getCarID() {
        return carID;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }
}
