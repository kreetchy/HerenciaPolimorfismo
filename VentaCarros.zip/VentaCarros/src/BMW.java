
public class BMW extends Car {

    public int BMW(CarType type, String carID, int maxSpeed) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
